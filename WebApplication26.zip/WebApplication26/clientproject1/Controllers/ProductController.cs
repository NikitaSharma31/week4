﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using WebApplication26.Models;

namespace clientproject1.Controllers
{
    public class ProductController : Controller
    {
        HttpClient hc = new HttpClient();
        public ProductController()
        {
            hc.BaseAddress = new Uri("https://localhost:44379/api/");
        }
        public ActionResult Index()
        {
            IEnumerable<Product> list;
            var consumedata = hc.GetAsync("Products");
            consumedata.Wait();
            var data = consumedata.Result;
            if (data.IsSuccessStatusCode)
            {
                var result = data.Content.ReadAsAsync<List<Product>>();
                result.Wait();
                list = result.Result;
                return View(list);
            }
            return Content("Error while retriving data");
        }
        public ActionResult Create()
        {

            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product p)
        {
            if (ModelState.IsValid)
            {
                var consumedata = hc.PostAsJsonAsync< Product > ("Products", p);
                consumedata.Wait();
                var data = consumedata.Result;
                if (data.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return View();
        }

        
        public ActionResult Edit(int id)
        {
            var consumedata = hc.GetAsync($"Products/{id}");
            consumedata.Wait();
            var data = consumedata.Result;
            if (data.IsSuccessStatusCode)
            {
                var res=data.Content.ReadAsAsync<Product>();
                res.Wait();
                return View(res.Result);
            }
            return Content("check id may be it doesn't exist");
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id,Product p)
        {
            if (ModelState.IsValid)
            {
                var consumedata=hc.PutAsJsonAsync<Product>($"Products/{id}", p);
                consumedata.Wait();
                var data = consumedata.Result;
                if (data.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                return Content("updation error happened in server");
            }
            return View();
        }
        public ActionResult Delete(int id)
        {
            var consumedata = hc.DeleteAsync($"Products/{id}");
            consumedata.Wait();
            var data = consumedata.Result;
            if (data.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return Content("can't delete some error happened in server while deleting");
        }
    }
}
