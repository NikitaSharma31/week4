﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication26.Models;

namespace WebApplication26.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private IProductRepository prep;

        public ProductsController(IProductRepository prep)
        {
            this.prep = prep;
        }
        [HttpGet]
        
        public async Task<IActionResult> GetAllProducts()
        {
            try
            {
                return Ok(await prep.GetProducts());
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "error in the server while executing code");
            }
        }
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var res=await prep.GetProduct(id);
            if (res == null)
            {
                return NotFound($"product with id:{id} is not found in the database ");
            }
            return Ok(res);
        }
        [HttpPost]
        public async Task<IActionResult> AddProduct(Product p)
        {
            if (p.ID != 0)
            {
                return BadRequest($"can't insert data to identity column given id={p.ID}");
            }
            var obj=await prep.AddProduct(p);
            return CreatedAtAction("GetProduct", new { id = obj.ID }, obj);
        }
        [HttpPut("{id:int}")]
        public async Task<IActionResult> EditProduct(int id,Product p)
        {
            if (id != p.ID)
            {
                return BadRequest("can't update a identtity column id as gave different Id");
            }
            var obj=await prep.GetProduct(id);
            if (obj == null)
            {
                return NotFound($"row with id={id} not found in the database");
            }
            return Ok(await prep.UpdateProduct(id, p));
        }
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var obj = await prep.GetProduct(id);
            if (obj == null)
            {
                return NotFound($"row with id={id} not found in the database");
            }
            return Ok(await prep.DeleteProduct(id));
        }
    }
}
