﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication26.Models
{
    public class AppContext:DbContext
    {
        
        public AppContext(DbContextOptions<AppContext> options):base(options)
        {

        }
        public DbSet<Product> sk_Products { set; get; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Product>().HasData(new Product()
            {
                ID = 1,
                Name = "Milk",
                price = 30
            }
                );
            modelBuilder.Entity<Product>().HasData(new Product()
            {
                ID = 2,
                Name = "Banana",
                price = 50
            });
        }
    }
}

