﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication26.Models
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppContext context;

        public ProductRepository(AppContext context )
        {
            this.context = context;
        }
        
        public async Task<Product> AddProduct(Product p)
        {
            var res=await context.sk_Products.AddAsync(p);
            await context.SaveChangesAsync();
            return res.Entity;
        }

        public async Task<Product> DeleteProduct(int id)
        {
            var obj=await context.sk_Products.FindAsync(id);
            context.Remove(obj);
            await context.SaveChangesAsync();
            return obj;
        }

        public async Task<Product> GetProduct(int id)
        {
            return context.sk_Products.Find(id);
        }

        public async Task<List<Product>> GetProducts()
        {
            return await context.sk_Products.ToListAsync();
        }

        public async Task<Product> UpdateProduct(int id, Product p)
        {
            var obj=await context.sk_Products.FindAsync(id);
            obj.Name = p.Name;
            obj.price = p.price;
            await context.SaveChangesAsync();
            return p;
        }
    }
}
