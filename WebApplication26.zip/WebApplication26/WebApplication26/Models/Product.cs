﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication26.Models
{
    public class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public float price { get; set; }
        
    }
}
