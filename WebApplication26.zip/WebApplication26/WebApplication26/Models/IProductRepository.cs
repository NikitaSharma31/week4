﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication26.Models
{
    public interface IProductRepository
    {
        Task<List<Product>> GetProducts();
        Task<Product> GetProduct(int id);
        Task<Product> AddProduct(Product p);
        Task<Product> UpdateProduct(int id, Product p);
        Task<Product> DeleteProduct(int id);
    }
}
