﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication26.Migrations
{
    public partial class mig1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "sk_Products",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    price = table.Column<float>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sk_Products", x => x.ID);
                });

            migrationBuilder.InsertData(
                table: "sk_Products",
                columns: new[] { "ID", "Name", "price" },
                values: new object[] { 1, "Milk", 30f });

            migrationBuilder.InsertData(
                table: "sk_Products",
                columns: new[] { "ID", "Name", "price" },
                values: new object[] { 2, "Banana", 50f });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "sk_Products");
        }
    }
}
